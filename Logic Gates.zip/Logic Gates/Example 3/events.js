P.on("click", function(){
	setColor(P);
});

Q.on("click", function(){
	setColor(Q);
});

circle3x1.on("click", function(){
	setColor(circle3x1);
})

circle3x2.on("click", function(){
	setColor(circle3x2);
})

circle3x3.on("click", function(){
	setColor(circle3x3);
})

circle3x4.on("click", function(){
	setColor(circle3x4);
})