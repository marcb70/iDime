/*creates an event each time a circle is clicked or tapped. Calls upon setColor() function in functions.js
*for devices with a mouse device, the click function is used. For touch devices such as mobile and tablet devices, the tap function is used.*/

circle5x1.on("click tap", function(){
	setColor(circle5x1);
})

circle5x2.on("click tap", function(){
	setColor(circle5x2);
})

circle5x3.on("click tap", function(){
	setColor(circle5x3);
})

circle5x4.on("click tap", function(){
	setColor(circle5x4);
})
circle5x5.on("click tap", function(){
	setColor(circle5x5);
})

circle5x6.on("click tap", function(){
	setColor(circle5x6);
})

circle5x7.on("click tap", function(){
	setColor(circle5x7);
})

circle5x8.on("click tap", function(){
	setColor(circle5x8);
})
circle5x9.on("click tap", function(){
	setColor(circle5x9);
})

circle5x10.on("click tap", function(){
	setColor(circle5x10);
})

circle5x11.on("click tap", function(){
	setColor(circle5x11);
})

circle5x12.on("click tap", function(){
	setColor(circle5x12);
})
circle5x13.on("click tap", function(){
	setColor(circle5x13);
})

circle5x14.on("click tap", function(){
	setColor(circle5x14);
})

circle5x15.on("click tap", function(){
	setColor(circle5x15);
})

circle5x16.on("click tap", function(){
	setColor(circle5x16);
})

circle6x1.on("click tap", function(){
	setColor(circle6x1);
})

circle6x2.on("click tap", function(){
	setColor(circle6x2);
})

circle6x3.on("click tap", function(){
	setColor(circle6x3);
})

circle6x4.on("click tap", function(){
	setColor(circle6x4);
})
circle6x5.on("click tap", function(){
	setColor(circle6x5);
})

circle6x6.on("click tap", function(){
	setColor(circle6x6);
})

circle6x7.on("click tap", function(){
	setColor(circle6x7);
})
circle6x9.on("click tap", function(){
	setColor(circle6x9);
})
circle6x8.on("click tap", function(){
	setColor(circle6x8);
})
circle6x10.on("click tap", function(){
	setColor(circle6x10);
})

circle6x11.on("click tap", function(){
	setColor(circle6x11);
})

circle6x12.on("click tap", function(){
	setColor(circle6x12);
})
circle6x13.on("click tap", function(){
	setColor(circle6x13);
})

circle6x14.on("click tap", function(){
	setColor(circle6x14);
})

circle6x15.on("click tap", function(){
	setColor(circle6x15);
})

circle6x16.on("click tap", function(){
	setColor(circle6x16);
})

circle7x1.on("click tap", function(){
	setColor(circle7x1);
})

circle7x2.on("click tap", function(){
	setColor(circle7x2);
})

circle7x3.on("click tap", function(){
	setColor(circle7x3);
})

circle7x4.on("click tap", function(){
	setColor(circle7x4);
})
circle7x5.on("click tap", function(){
	setColor(circle7x5);
})

circle7x6.on("click tap", function(){
	setColor(circle7x6);
})

circle7x7.on("click tap", function(){
	setColor(circle7x7);
})

circle7x8.on("click tap", function(){
	setColor(circle7x8);
})
circle7x9.on("click tap", function(){
	setColor(circle7x9);
})

circle7x10.on("click tap", function(){
	setColor(circle7x10);
})

circle7x11.on("click tap", function(){
	setColor(circle7x11);
})

circle7x12.on("click tap", function(){
	setColor(circle7x12);
})
circle7x13.on("click tap", function(){
	setColor(circle7x13);
})

circle7x14.on("click tap", function(){
	setColor(circle7x14);
})

circle7x15.on("click tap", function(){
	setColor(circle7x15);
})

circle7x16.on("click tap", function(){
	setColor(circle7x16);
})

circle8x1.on("click tap", function(){
  setColor(circle8x1);
})

circle8x2.on("click tap", function(){
  setColor(circle8x2);
})

circle8x3.on("click tap", function(){
  setColor(circle8x3);
})

circle8x4.on("click tap", function(){
  setColor(circle8x4);
})
circle8x5.on("click tap", function(){
  setColor(circle8x5);
})

circle8x6.on("click tap", function(){
  setColor(circle8x6);
})

circle8x7.on("click tap", function(){
  setColor(circle8x7);
})

circle8x8.on("click tap", function(){
  setColor(circle8x8);
})
circle8x9.on("click tap", function(){
  setColor(circle8x9);
})

circle8x10.on("click tap", function(){
  setColor(circle8x10);
})

circle8x11.on("click tap", function(){
  setColor(circle8x11);
})

circle8x12.on("click tap", function(){
  setColor(circle8x12);
})
circle8x13.on("click tap", function(){
  setColor(circle8x13);
})

circle8x14.on("click tap", function(){
  setColor(circle8x14);
})

circle8x15.on("click tap", function(){
  setColor(circle8x15);
})

circle8x16.on("click tap", function(){
  setColor(circle8x16);
})
//calls upon clearColumn() in functions.js. used to change each cirlce in the specified column to clear, which may help the user see the needed columns more clearly.
tableP.on("click tap", function(){
	//console.log("tablep clicked");
	clearColumn("c1");
})
tableQ.on("click tap", function(){
	clearColumn("c2");
})
tableR.on("click tap", function(){
	clearColumn("c3");
})
tableS.on("click tap", function(){
	clearColumn("c4");
})