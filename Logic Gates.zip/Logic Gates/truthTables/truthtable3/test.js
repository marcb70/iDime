/*TESTING FUNCTIONS*/

function createCircles(fill, col, row, xpos){
	for(var i = 1; i < row+1; i++){
		var name= "circle"+col+"x"+i;
		var name = new Kinetic.Circle({
			x: xpos;
			y
		});
	}
}