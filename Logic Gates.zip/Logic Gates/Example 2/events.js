P.on("click", function(){
	setColor(P);
});

Q.on("click", function(){
	setColor(Q);
});

R.on("click", function(){
	setColor(R);
});

S.on("click", function(){
	setColor(S);
});